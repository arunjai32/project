package controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name = "AdminDetails", urlPatterns ={"/AdminDetails"})
public class AdminDetails extends HttpServlet {
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            dao.AdminDAO obj=new dao.AdminDAO();
            boolean s=obj.AdminDetails();
            System.out.println(s);
            System.out.println("Success");
        } catch (Exception ex) {
          Logger.getLogger(AdminDetails.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
}

