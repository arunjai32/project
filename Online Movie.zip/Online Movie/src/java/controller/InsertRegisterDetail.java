package controller;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name = "InsertRegisterDetail", urlPatterns ={"/InsertRegisterDetail"})
public class InsertRegisterDetail extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
           String uid=request.getParameter("uid");
           String uname=request.getParameter("uname"); 
           String password=request.getParameter("password"); 
           String email=request.getParameter("email"); 
           String mobile=request.getParameter("mobile"); 
           String address=request.getParameter("address"); 
           out.println(uid+" "+uname+" "+password+" "+email+" "+mobile+" "+address);
           dao.RegisterDAO obj=new dao.RegisterDAO();
           
           if(obj.registerDetail(uid, uname, password, email,mobile,address))
           {
               out.println("successful");
           }
           else
           {
               out.println("Error");
           }
        }
       catch(Exception e)
      {
          System.out.println("Exeception Arised");
          e.printStackTrace(out);
      }
    }
}
