
package controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet(name = "Logincheck", urlPatterns = {"/Logincheck"})
public class LoginCheck extends HttpServlet {
protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try  {
            System.out.println("start");
            String uid=request.getParameter("uid");
            String password=request.getParameter("password");
            System.out.println("str1");
            dao.LoginDAO obj=new dao.LoginDAO();
            System.out.println("str2");
            String role=obj.checkLogin(uid,password);
            System.out.println(role);
            if(role.equals("admin")){ HttpSession session=request.getSession();
                session.setAttribute("userid",uid);
                RequestDispatcher dispatch=request.getRequestDispatcher("AdminHome.jsp");
                dispatch.forward(request,response);
                
            }
            else if(role.equals("user"))
            {
                HttpSession session=request.getSession();
                session.setAttribute("userid",uid);
                RequestDispatcher dispatch=request.getRequestDispatcher("UserHome.jsp");
                dispatch.forward(request,response);
            }
            else
            {
                HttpSession session=request.getSession();
            session.setAttribute("Errormsg","Userid and password does not match");
                RequestDispatcher dispatch=request.getRequestDispatcher("login.jsp");
                dispatch.forward(request,response);
               
            }
        }
        catch(Exception e)
       {
        out.println("exception Arised"); 
        e.printStackTrace(out);
        }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
