package dao;
import java.io.PrintWriter;
import javax.sql.*;
import java.sql.*;
import javax.naming.*;
public class AdminDAO {
 
    Connection conn;
   public AdminDAO()throws Exception
   {
    System.out.println("starting");
       Context ctx=new InitialContext();
       DataSource ds=(DataSource)ctx.lookup("jdbc/MyDsn");
       System.out.println("db loaded");
       conn=ds.getConnection();
   }
   public boolean AdminDetails()throws Exception
   {
       try{
   
       PreparedStatement psmt1=conn.prepareStatement("select * from USERCREDENTIAL");
       PreparedStatement psmt2=conn.prepareStatement("Select * from USERDETAILS");
       ResultSet rs1=null;
       ResultSet rs2=null;
       rs1=psmt1.executeQuery();
       while (rs1.next())
       {
           for(int i=1;i<=6;i++)
           System.out.println(rs1.getString(i) + " " );
       }
       
       }
       catch (Exception e){}
       return true;
   }
}
   