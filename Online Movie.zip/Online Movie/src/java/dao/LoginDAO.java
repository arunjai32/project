package dao;
import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
public class LoginDAO {
   Connection conn;
   public LoginDAO()throws Exception
   {
       Context ctx=new InitialContext();
       DataSource ds=(DataSource)ctx.lookup("jdbc/MyDsn");
       conn=ds.getConnection();
   }
    public String checkLogin(String uid,String password)throws Exception
    {
        System.out.println("run");
       PreparedStatement psmt=conn.prepareStatement("select userid,password from usercredential where userid='"+uid+"' and password='"+password+"'");
        
        ResultSet rs=psmt.executeQuery();
        String role="";
        System.out.println("run1");
	while(rs.next())
	{
        String uid1=rs.getString(1);
	String password1=rs.getString(2);
        System.out.println(uid1);
        System.out.println(password1);
        System.out.println("run2");
        System.out.println(uid);
        System.out.println(password);
        
        if((uid==uid1)&&(password==password1))
            
        {
            System.out.println("Inside");
            PreparedStatement psmt1=conn.prepareStatement("select role from usercredential where userid='"+uid+"' and password='"+password+"'");
            ResultSet rs1=psmt1.executeQuery();
            role=rs1.getString(3);
            System.out.println(role);
            System.out.println("run3");
            return role;
        }
        else
        {
            
            role="Error";
            System.out.println(role);
        }
        }
        return role;
    }
    
}
