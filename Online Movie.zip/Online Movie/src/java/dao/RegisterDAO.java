
package dao;
import java.io.PrintWriter;
import javax.sql.*;
import java.sql.*;
import javax.naming.*;
public class RegisterDAO {
 
    Connection conn;
   public RegisterDAO()throws Exception
   {
    System.out.println("starting");
       Context ctx=new InitialContext();
       DataSource ds=(DataSource)ctx.lookup("jdbc/MyDsn");
       System.out.println("db loaded");
       conn=ds.getConnection();
   }
   
public boolean registerDetail(String uid,String uname,String password,String email,String mobile, String address)throws Exception  
{
    System.out.println("ru");
    PreparedStatement psmt1=conn.prepareStatement("insert into USERCREDENTIAL values(?,?,?)");
    System.out.println("ru1");
    PreparedStatement psmt2=conn.prepareStatement("insert into USERDETAILS values(?,?,?,?,?)");
    System.out.println("loaded");
    psmt1.setString(1,uid);
    psmt1.setString(2,password);
    psmt1.setString(3,"USER");
    
    psmt2.setString(1, uid);
    psmt2.setString(2,uname);
    psmt2.setString(3, email);
    psmt2.setString(4,mobile);
    psmt2.setString(5,address);
    System.out.println("done");
    int i=psmt1.executeUpdate();
    System.out.println("done1");
    int j=psmt2.executeUpdate();
    System.out.println("done2");
    if(i>0 && j>0)
    {
    return true;
    }
    else
    {
        return false;
}

} 
}   




