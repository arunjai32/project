function CheckLoginForm()
{
   var uid=document.forms["login"]["uid"].value;
   var password1=document.forms["login"]["password"].value;
  if(uid==null  ||  uid=="")
  {
      alert("user id cannot be blank");
      return false;
      
  }
  if(password1==null || password1=="")
  {
      alert("password cannot be blank");
      return false;
  } 
  if(password1.length<6)
  {
      alert("password should be equal to 6");
  }
  if(uid.length<4)
  {
      alert("user id should be equal to 4 char");
  }
}
function CheckRegisterForm()
{
    
}


